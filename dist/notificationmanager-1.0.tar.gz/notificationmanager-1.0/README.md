# My Package

A simple Notification package.

Capapilities:
1- create new notification
2- view notification
3- list all notifications
4- show number of unread notifications

## Installation

```bash
pip install NotificationManager